import React from 'react';
import { Col, Container, Jumbotron, Row } from 'react-bootstrap'
import { NavLink } from 'react-router-dom';
import Layout from '../../components/Layout';
import './style.css';
import logo from './anime.png';
import logo1 from './pic2.png';
import logo2 from './onion.jpg';
import logo3 from './tomato.jpg';
import logo4 from './capsi.jpeg';
import logo5 from './cauliflower.jpeg';
import logo6 from './curd.jpg';
import logo7 from './ghee.jpg';
import logo8 from './arogya_milk.png';

import {RemoveScrollBar} from 'react-remove-scroll-bar';
import { useDispatch, useSelector } from 'react-redux';
import state from '../../reducers/auth_reducers';
import {Button} from 'react-bootstrap';
import Card from "react-bootstrap/Card";
import Carousel from 'react-bootstrap/Carousel';




/**
* @author
* @function Home
**/


const Home = (props) => {
  const auth = useSelector(state => state.auth);;
  console.log(auth.authenticate)
  if(auth.authenticate){
  return(
    <Layout sidebar>
      <div>
        <h2> Best Sellers</h2>
      </div>
        <div class="row">
          <br></br>
        <Card style={{ width: '20rem', marginLeft:'5%',marginTop:'2%' }}>
          <Card.Img variant="top" src={logo2}  style={{width:'100%'}} />
            <Card.Body>
                <div class="column">
                  {/* <img src={logo2} alt="onion" style={{width:'500%'}}></img> */}
                </div>
               {/* <Button variant="primary">Go somewhere</Button> */}
            </Card.Body>
         </Card>
         

         <Card style={{ width: '20rem', marginLeft:'2%', marginTop:'2%' }}>
          <Card.Img variant="top" src={logo3} alt="Organic-tomato" style={{width:'90%',marginLeft:'1%'}} />
            <Card.Body>
                <div class="column">
                  {/* <img src={logo2} alt="onion" style={{width:'500%'}}></img> */}
                </div>
               {/* <Button variant="primary">Go somewhere</Button> */}
            </Card.Body>
         </Card>

         <Card style={{ width: '20rem', marginLeft:'2%', marginTop:'2%' }}>
          <Card.Img variant="top" src={logo4} alt="Organic-Capsicum" style={{width:'50%',height:'100%',marginLeft:'25%'}} />
            <Card.Body>
                <div class="column">
                  {/* <img src={logo2} alt="onion" style={{width:'500%'}}></img> */}
                </div>
               {/* <Button variant="primary">Go somewhere</Button> */}
            </Card.Body>
         </Card>


         <Card style={{ width: '20rem', marginLeft:'2%', marginTop:'2%' }}>
          <Card.Img variant="top" src={logo5} alt="Cauliflower" style={{width:'50%',height:'100%',marginLeft:'25%'}} />
            <Card.Body>
                <div class="column">
                  {/* <img src={logo2} alt="onion" style={{width:'500%'}}></img> */}
                </div>
               {/* <Button variant="primary">Go somewhere</Button> */}
            </Card.Body>
         </Card>
        </div>
  
        

            <Row >
                    <p style={{marginLeft:'12%', fontSize:'20px'}}>Onions</p>
                    <p style={{marginLeft:'18%',fontSize:'20px'}}>Organic Tomato</p>
                    <p style={{marginLeft:'14%',fontSize:'20px'}}>Organic Capsicum</p>
                    <p style={{marginLeft:'14%',fontSize:'20px'}}>Cauliflower</p>
            </Row>

                <Carousel>
                   <Carousel.Item interval={1000}>
                       <img className="d-block w-10" src={logo6}  style={{width:'40%',marginLeft:'25%'}} alt="First slide"/>
                        <Carousel.Caption style={{color: "black"}}>
                            {/* <h3>CURD</h3> */}
                            
                        </Carousel.Caption>
                        </Carousel.Item>
                    <Carousel.Item interval={5000}>
                        <img className="d-block w-10" src={logo7} style={{width:'40%',marginLeft:'25%'}} alt="Second slide"/>
                    <Carousel.Caption style={{color: "red"}} >
                                                      {/* <h3>GHEE</h3> */}
                        
                    </Carousel.Caption>
                    </Carousel.Item>
                    <Carousel.Item interval={5000}>
                      <img className="d-block w-10" src={logo8} style={{width:'40%',marginLeft:'25%'}}  alt="Third slide" />
                    <Carousel.Caption style={{color: "black", marginRight:'10%'}}>
                                            {/* <h3 >MILK</h3> */}
                      
                      </Carousel.Caption>
                    </Carousel.Item>
                </Carousel>

       
    </Layout>
   )
  }
else{
    return(
      <Layout className="layout">
        <RemoveScrollBar />
        <Container fluid>
          <Jumbotron style={{ margin:'1rem'}} className="text-center">
              <h1> Welcome to Farmer Customer Connect</h1><hr></hr>
              <p> Farmer Customer Connect is an interface between farmers and customers without any middlemen. Customers can enjoy the organic farm products at low prices.</p>
          </Jumbotron>
        </Container>       
   
          <div class="row">
            <div class="column">
              <img src={logo} alt="Carrot" style={{width:'70%',marginLeft:'100%'}}></img>
            </div>
            <div class="column">
              <img src={logo1} alt="veggies" style={{width:'100%',marginLeft:'140%',marginTop:'12%'}}></img>
            </div>
          </div>

          
  
          
      </Layout>
     )

 }

 }

export default Home